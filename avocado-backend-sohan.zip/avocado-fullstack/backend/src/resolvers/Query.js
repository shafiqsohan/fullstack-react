const Query = {};

module.exports = Query;
