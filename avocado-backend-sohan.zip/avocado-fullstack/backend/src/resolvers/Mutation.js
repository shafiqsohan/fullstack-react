const mutations = {};

module.exports = mutations;
